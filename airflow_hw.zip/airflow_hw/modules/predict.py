import json
import dill
import os
import pandas as pd
from datetime import datetime

path = os.environ.get('PROJECT_PATH', '.')


def read_model():

    # Если несколько моделей, то выберем модель с максимальной датой создания:
    list_of_models = [os.path.join(f'{path}/data/models', one_file) for one_file in os.listdir(f'{path}/data/models') if (one_file[-4:] == ".pkl")]
    if len(list_of_models) == 0:
    # Нет ни одного файла, поэтому выходим без обработки.
        logging.info(f'There are no files to process.')

    full_model_file_name = max(list_of_models, key=os.path.getctime)

    with open(full_model_file_name, 'rb') as file:
        model = dill.load(file)

    return model


def predict():

    df_preds = pd.DataFrame(columns=['DataFile', 'Prediction'])

    for file in os.listdir(f'{path}/data/test'):

        with open(path+'/data/test/'+file) as fin:
            test_data = json.load(fin)

        df = pd.DataFrame.from_dict([test_data])
        y = read_model().predict(df)

        df_to_concat = pd.DataFrame([[file, y[0]]], columns=['DataFile', 'Prediction'])
        df_preds = pd.concat([df_preds, df_to_concat], axis=0, ignore_index=True)

    df_preds.to_csv(f'{path}/data/predictions/prediction_{datetime.now().strftime("%Y%m%d%H%M")}.csv', index=False)


if __name__ == '__main__':
    predict()